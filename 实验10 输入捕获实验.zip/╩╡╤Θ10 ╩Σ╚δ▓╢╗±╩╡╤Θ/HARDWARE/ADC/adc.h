#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"


void Adc1_Multi_Init(void);
void Adc2_Multi_Init(void);
void MY_ADC_Init(void);
void task_adc(void);

#endif 
